# Automatically generated file, do not edit.

PLATFORM = "android_arm64"
LIB_NAME = "libtorrest.so"
EXE_NAME = "torrest"
